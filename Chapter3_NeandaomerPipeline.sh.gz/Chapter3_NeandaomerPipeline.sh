# CALL MODULES
#module avail 
module load samtools/v1.6 
module load perl/v5.24.0
module load vcftools/v0.1.14
module load bedtools/v2.26.0 
module load emboss/v6.6.0 
module load bedops/v2.4.26


# gunzip vcf
xsbatch -c 1 --mem-per-cpu=12000 -J down -- gunzip AltaiNea.hg19_1000g.1.mod.vcf.gz
xsbatch -c 1 --mem-per-cpliftu=12000 -J down -- gunzip AltaiNea.hg19_1000g.5.mod.vcf.gz
xsbatch -c 1 --mem-per-cpu=12000 -J down -- gunzip AltaiNea.hg19_1000g.7.mod.vcf.gz
xsbatch -c 1 --mem-per-cpu=12000 -J down -- gunzip AltaiNea.hg19_1000g.10.mod.vcf.gz
xsbatch -c 1 --mem-per-cpu=12000 -J down -- gunzip AltaiNea.hg19_1000g.15.mod.vcf.gz
xsbatch -c 1 --mem-per-cpu=12000 -J down -- gunzip AltaiNea.hg19_1000g.18.mod.vcf.gz

#vcf to tab
xsbatch -c 1 --mem-per-cpu=12000 -J vcftab -- vcf-to-tab < AltaiNea.hg19_1000g.1.mod.vcf > AltaiNea.hg19_1000g.1.mod.tab
xsbatch -c 1 --mem-per-cpu=12000 -J vcftab -- vcf-to-tab < AltaiNea.hg19_1000g.5.mod.vcf > AltaiNea.hg19_1000g.5.mod.tab
xsbatch -c 1 --mem-per-cpu=12000 -J vcftab -- vcf-to-tab < AltaiNea.hg19_1000g.7.mod.vcf > AltaiNea.hg19_1000g.7.mod.tab
xsbatch -c 1 --mem-per-cpu=12000 -J vcftab -- vcf-to-tab < AltaiNea.hg19_1000g.10.mod.vcf > AltaiNea.hg19_1000g.10.mod.tab
xsbatch -c 1 --mem-per-cpu=12000 -J vcftab -- vcf-to-tab < AltaiNea.hg19_1000g.15.mod.vcf > AltaiNea.hg19_1000g.15.mod.tab
xsbatch -c 1 --mem-per-cpu=12000 -J vcftab -- vcf-to-tab < AltaiNea.hg19_1000g.18.mod.vcf > AltaiNea.hg19_1000g.18.mod.tab


vcf-to-tab < AltaiNea.hg19_1000g.1.mod.vcf > AltaiNea.hg19_1000g.1.mod.tab &
vcf-to-tab < AltaiNea.hg19_1000g.5.mod.vcf > AltaiNea.hg19_1000g.5.mod.tab &
vcf-to-tab < AltaiNea.hg19_1000g.7.mod.vcf > AltaiNea.hg19_1000g.7.mod.tab &
vcf-to-tab < AltaiNea.hg19_1000g.10.mod.vcf > AltaiNea.hg19_1000g.10.mod.tab &
vcf-to-tab < AltaiNea.hg19_1000g.15.mod.vcf > AltaiNea.hg19_1000g.15.mod.tab &
vcf-to-tab < AltaiNea.hg19_1000g.18.mod.vcf > AltaiNea.hg19_1000g.18.mod.tab &

#tab to kind of bed
awk '{ print $1 "\t" $2 "\t" ($2+1) "\t" $4 "\t" substr($4,0,1)}' AltaiNea.hg19_1000g.1.mod.tab > AltaiNea.hg19_1000g.1.mod.kind.bed &
awk '{ print $1 "\t" $2 "\t" ($2+1) "\t" $4 "\t" substr($4,0,1)}' AltaiNea.hg19_1000g.5.mod.tab > AltaiNea.hg19_1000g.5.mod.kind.bed &
awk '{ print $1 "\t" $2 "\t" ($2+1) "\t" $4 "\t" substr($4,0,1)}' AltaiNea.hg19_1000g.7.mod.tab > AltaiNea.hg19_1000g.7.mod.kind.bed &
awk '{ print $1 "\t" $2 "\t" ($2+1) "\t" $4 "\t" substr($4,0,1)}' AltaiNea.hg19_1000g.10.mod.tab > AltaiNea.hg19_1000g.10.mod.kind.bed &
awk '{ print $1 "\t" $2 "\t" ($2+1) "\t" $4 "\t" substr($4,0,1)}' AltaiNea.hg19_1000g.15.mod.tab > AltaiNea.hg19_1000g.15.mod.kind.bed &
awk '{ print $1 "\t" $2 "\t" ($2+1) "\t" $4 "\t" substr($4,0,1)}' AltaiNea.hg19_1000g.18.mod.tab > AltaiNea.hg19_1000g.18.mod.kind.bed &

#add chr
sed 's/^/chr/' AltaiNea.hg19_1000g.1.mod.kind.bed > AltaiNea.hg19_1000g.1.mod.kind2.bed &
sed 's/^/chr/' AltaiNea.hg19_1000g.5.mod.kind.bed > AltaiNea.hg19_1000g.5.mod.kind2.bed &
sed 's/^/chr/' AltaiNea.hg19_1000g.7.mod.kind.bed > AltaiNea.hg19_1000g.7.mod.kind2.bed &
sed 's/^/chr/' AltaiNea.hg19_1000g.10.mod.kind.bed > AltaiNea.hg19_1000g.10.mod.kind2.bed &
sed 's/^/chr/' AltaiNea.hg19_1000g.15.mod.kind.bed > AltaiNea.hg19_1000g.15.mod.kind2.bed &
sed 's/^/chr/' AltaiNea.hg19_1000g.18.mod.kind.bed > AltaiNea.hg19_1000g.18.mod.kind2.bed &

#remove first line
xsbatch -c 1 --mem-per-cpu=12000 -J Scmd -- sed -i '1d' AltaiNea.hg19_1000g.1.mod.kind2.bed
xsbatch -c 1 --mem-per-cpu=12000 -J down -- sed -i '1d' AltaiNea.hg19_1000g.5.mod.kind2.bed
xsbatch -c 1 --mem-per-cpu=12000 -J down -- sed -i '1d' AltaiNea.hg19_1000g.7.mod.kind2.bed
xsbatch -c 1 --mem-per-cpu=12000 -J down -- sed -i '1d' AltaiNea.hg19_1000g.10.mod.kind2.bed
xsbatch -c 1 --mem-per-cpu=12000 -J down -- sed -i '1d' AltaiNea.hg19_1000g.15.mod.kind2.bed
xsbatch -c 1 --mem-per-cpu=12000 -J down -- sed -i '1d' AltaiNea.hg19_1000g.18.mod.kind2.bed

#kind of bed file from vcf19 to hg38 
xsbatch -c 1 --mem-per-cpu=12000 -J down -- liftOver AltaiNea.hg19_1000g.1.mod.kind2.bed hg19ToHg38.over.chain.gz liftOverhg38_AltaiNea_Chr1.bed liftOverhg38_AltaiNea_Chr1.unmapped
xsbatch -c 1 --mem-per-cpu=12000 -J down -- liftOver AltaiNea.hg19_1000g.5.mod.kind2.bed hg19ToHg38.over.chain.gz liftOverhg38_AltaiNea_Chr5.bed liftOverhg38_AltaiNea_Chr5.unmapped
xsbatch -c 1 --mem-per-cpu=12000 -J down -- liftOver AltaiNea.hg19_1000g.7.mod.kind2.bed hg19ToHg38.over.chain.gz liftOverhg38_AltaiNea_Chr7.bed liftOverhg38_AltaiNea_Chr7.unmapped
xsbatch -c 1 --mem-per-cpu=12000 -J down -- liftOver AltaiNea.hg19_1000g.10.mod.kind2.bed hg19ToHg38.over.chain.gz liftOverhg38_AltaiNea_Chr10.bed liftOverhg38_AltaiNea_Chr10.unmapped
xsbatch -c 1 --mem-per-cpu=12000 -J down -- liftOver AltaiNea.hg19_1000g.15.mod.kind2.bed hg19ToHg38.over.chain.gz liftOverhg38_AltaiNea_Chr15.bed liftOverhg38_AltaiNea_Chr15.unmapped
xsbatch -c 1 --mem-per-cpu=12000 -J down -- liftOver AltaiNea.hg19_1000g.18.mod.kind2.bed hg19ToHg38.over.chain.gz liftOverhg38_AltaiNea_Chr18.bed liftOverhg38_AltaiNea_Chr18.unmapped


bedextract liftOverhg38_AltaiNea_Chr15.bed CYP11A1.bed


#amother way vcf hg10 to ch38
java -jar picard.jar LiftoverVcf \
     I=input.vcf \
     O=lifted_over.vcf \
     CHAIN=b37tohg19.chain \
     REJECT=rejected_variants.vcf \
     R=reference_sequence.fasta


## SELECT PHEROMONES bed 0 amd +1
#extract subset from bed file
bedextract liftOverhg38_AltaiNea_Chr15.bed CYP11A1.bed > CDS_CYP11A1.bed
#bed to fasta
awk '{ print $5 }' CDS_CYP11A1.bed | tr -d "[:space:]" |awk 'BEGIN { ORS=""; print ">CDS_CYP11A1\n" } { print }' > CDS_CYP11A1.fasta
#reverse complementary sequence in case to be necesary
revseq CYP11A1.Altai.fasta -reverse -complement -outseq reverseCYP11A1.Altai.fasta

#extract subset from bed file
bedextract liftOverhg38_AltaiNea_Chr10.bed CYP17A1.bed > CDS_CYP17A1.bed
#bed to fasta
awk '{ print $5 }' CDS_CYP17A1.bed | tr -d "[:space:]" |awk 'BEGIN { ORS=""; print ">CDS_CYP17A1\n" } { print }' > CDS_CYP17A1.fasta
#reverse complementary sequence in case to be necesary
revseq CYP17A1.Altai.fasta -reverse -complement -outseq reverseCYP17A1.Altai.fasta

#extract subset from bed file bed 0 amd +1
bedextract liftOverhg38_AltaiNea_Chr7.bed POR.bed > CDS_POR.bed
#bed to fasta
awk '{ print $5 }' CDS_POR.bed | tr -d "[:space:]" |awk 'BEGIN { ORS=""; print ">CDS_POR\n" } { print }' > CDS_POR.fasta

#extract subset from bed file
bedextract CYB5A.hg38.bed CYB5A.bed > CDS_CYB5A.bed
#bed to fasta
awk '{ print $5 }' CDS_CYB5A.bed | tr -d "[:space:]" |awk 'BEGIN { ORS=""; print ">CDS_CYB5A\n" } { print }' > CDS_CYB5A.fasta
#reverse complementary sequence in case to be necesary
revseq CDS_CYB5A.fasta -reverse -complement -outseq reverseCYB5A.Altai.fasta

#extract subset from bed file
bedextract liftOverhg38_AltaiNea_Chr1.bed HSD3B1.bed > CDS_HSD3B1.bed
#bed to fasta
awk '{ print $5 }' CDS_HSD3B1.bed | tr -d "[:space:]" |awk 'BEGIN { ORS=""; print ">CDS_HSD3B1\n" } { print }' > CDS_HSD3B1.fasta

#extract subset from bed file
bedextract liftOverhg38_AltaiNea_Chr10.bed AKR1C3.bed > CDS_AKR1C3.bed
#bed to fasta
awk '{ print $5 }' CDS_AKR1C3.bed | tr -d "[:space:]" |awk 'BEGIN { ORS=""; print ">CDS_AKR1C3\n" } { print }' > CDS_AKR1C3.fasta

#extract subset from bed file
bedextract liftOverhg38_AltaiNea_Chr5.bed SRD5A1.bed > CDS_SRD5A1.bed
#bed to fasta
awk '{ print $5 }' CDS_SRD5A1.bed | tr -d "[:space:]" |awk 'BEGIN { ORS=""; print ">CDS_SRD5A1\n" } { print }' > CDS_SRD5A1.fasta

#extract subset from bed file
bedextract liftOverhg38_AltaiNea_Chr10.bed AKR1C4.bed > CDS_AKR1C4.bed
#bed to fasta
awk '{ print $5 }' CDS_AKR1C4.bed | tr -d "[:space:]" |awk 'BEGIN { ORS=""; print ">CDS_AKR1C4\n" } { print }' > CDS_AKR1C4.fasta


#Subset of AKR1C3
tabix /groups/hologenomics/sarai/data/neadeamore/pheromonesExtraction/altai_vcf/AltaiNea.hg19_1000g.10.mod.vcf.gz Chr10:5,094,444-5,107,503


vcftools --gzvcf /groups/hologenomics/sarai/data/neadeamore/pheromonesExtraction/altai_vcf/AltaiNea.hg19_1000g.10.mod.vcf.gz --bed AKR1C3.correct.bed --out altai_AKR1C3.vcf --recode --keep-INFO-all 


intersectBed -a /groups/hologenomics/sarai/data/neadeamore/pheromonesExtraction/altai_vcf/AltaiNea.hg19_1000g.10.mod.vcf.gz -b AKR1C3.correct.bed -header > output.vcf
